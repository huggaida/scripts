# Blender Modular tree addon

This addon for blender allows the creation of realistic trees with the node editor.

Documentation: https://github.com/MaximeHerpin/modular_tree/wiki/Documentation

