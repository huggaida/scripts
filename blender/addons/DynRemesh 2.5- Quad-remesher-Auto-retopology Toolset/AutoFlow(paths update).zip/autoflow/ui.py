import bpy
import os
from bpy.types import Panel

from . import functions as funcs


class VIEW3D_PT_autoflow(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Retopology"
    bl_label = "Autoflow"

    def draw(self, context):
        af = context.scene.autoflow

        layout = self.layout
        layout.prop(af, "min_cost_flow")
        layout.prop(af, "sharp_preserving")
        if funcs.sat_flag_is_allowed():
            layout.prop(af, "flip_removal")
        layout.prop(af, "require_manifold")
        layout.prop(af, "resolution")

        col = layout.column()
        if not funcs.quadriflow_path_pref_is_set():
            col.operator("autoflow.remesh",
                         text="Set Quadriflow path",
                         icon="ERROR")
            col.enabled = False
        elif not os.path.exists(funcs.get_quadriflow_path_from_addon_prefs()):
            col.operator("autoflow.remesh",
                         text="Quadriflow path not found",
                         icon="ERROR")
            col.enabled = False
        elif not funcs.object_can_be_remeshed(
                bpy.context.view_layer.objects.active):
            col.operator("autoflow.remesh",
                         text="Select a mesh in object mode",
                         icon="ERROR")
            col.enabled = False
        elif not funcs.autoflow_is_compatible_with_os():
            col.operator("autoflow.remesh",
                         text="Autoflow is for Windows, Linux, or Mac",
                         icon="ERROR")
            col.enabled = False
        else:
            col.operator("autoflow.remesh", icon="FILE_TICK")
