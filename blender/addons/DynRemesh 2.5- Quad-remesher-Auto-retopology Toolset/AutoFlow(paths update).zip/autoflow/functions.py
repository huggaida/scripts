import bmesh
import bpy
import os
import subprocess
import sys


def all_bmesh_edges_are_manifold(bmesh):
    return all_elements_are_manifold(bmesh.edges)


def all_bmesh_verts_are_manifold(bmesh):
    return all_elements_are_manifold(bmesh.verts)


def all_elements_are_manifold(elements):
    for element in elements:
        if not element.is_manifold:
            return False
    return True


def autoflow_is_compatible_with_os():
    # Compatible operating systems may change in the future.
    return os_is_linux() or os_is_mac() or os_is_windows()


def get_addon_preference(addon_name, preference, default=None):
    addon_preferences = get_addon_preferences(addon_name)
    return addon_preferences.get(preference, default)


def get_addon_preferences(addon_name):
    enabled_addons = get_enabled_addons()
    if addon_name in enabled_addons:
        return enabled_addons[addon_name].preferences
    else:
        return {}


def get_enabled_addons():
    return bpy.context.preferences.addons


def get_file_directory(file_path):
    return os.path.dirname(file_path)


def get_file_extension(file_path):
    return os.path.splitext(file_path)[-1][1:].lower()


def get_file_name(file_path):
    return os.path.splitext(os.path.basename(file_path))[0]


def get_objects_in_view_layer(view_layer, objects_to_ignore=()):
    """Gets objects in the given view layer, regardless of the
    visibility or collection of the objects.  Objects in
    objects_to_ignore are not included.
    """
    return [obj for obj in view_layer.objects if obj not in objects_to_ignore]


def get_os():
    return sys.platform.lower()


def get_quadriflow_output_path(input_path):
    return modify_file_name_in_path(input_path, suffix="_quadriflow")


def get_quadriflow_path_from_addon_prefs():
    return get_addon_preference("autoflow", "quadriflow_path", default="")


def get_quadriflow_timeout_from_addon_prefs():
    timeout = get_addon_preference("autoflow", "quadriflow_timeout", default=0)
    if timeout > 0:
        return timeout
    else:
        return None


def get_selected_objects_in_view_layer(view_layer, objects_to_ignore=()):
    """Gets selected objects in the given view layer, regardless of the
    visibility or collection of the objects.  Objects in
    objects_to_ignore are not included.
    """
    return [obj for obj in view_layer.objects.selected
            if obj not in objects_to_ignore]


def get_strings_from_bstring(bstring, encoding="UTF-8", delimiter="\n"):
    if bstring:
        return bstring.decode(encoding).split(delimiter)
    else:
        return []


def mesh_is_manifold(mesh):
    obj_bmesh = bmesh.new()
    obj_bmesh.from_mesh(mesh)

    edges_and_verts_are_manifold = all_bmesh_edges_are_manifold(obj_bmesh) \
                                   and all_bmesh_verts_are_manifold(obj_bmesh)

    obj_bmesh.free()
    return edges_and_verts_are_manifold


def modify_file_name_in_path(file_path, prefix="", suffix=""):
    """
    Modifies the given file_path by prepending and/or appending strings
    to the name of the file in the path.

    Args:
        file_path: A string representing a path to a file.
        prefix: A string that is prepended to the file name in
            the given file_path.
        suffix: A string that is appended to the file name in
            the given file_path.

    Returns:
        A string representing the given file_path after the file name
        has had strings prepended and/or appended.

        For example:
        If file_path == "/usr/file.jpg", prefix == "updated_",
        and suffix == "_modified", then this function returns
        "/usr/updated_file_modified.jpg".
    """
    return os.path.join(get_file_directory(file_path),
                        "".join([prefix,
                                 get_file_name(file_path),
                                 suffix,
                                 "." * path_has_an_extension(file_path),
                                 get_file_extension(file_path)]))


def object_can_be_remeshed(obj):
    """Determines if the given object can be remeshed with Autoflow."""
    return object_has_properties(obj, mode='OBJECT', type='MESH') \
           and obj.select_get()


def object_has_properties(obj, **properties):
    """Determines if obj.key == properties[key] for each key in
    the given properties dictionary.
    """
    for prop_name in properties:
        if not hasattr(obj, prop_name) \
                or getattr(obj, prop_name) != properties[prop_name]:
            return False
    return True


def os_is_linux():
    return get_os().startswith("linux")


def os_is_mac():
    return get_os().startswith("darwin")


def os_is_windows():
    return get_os().startswith("win")


def path_has_an_extension(path):
    return len(get_file_extension(path)) > 0


def print_strings_from_bstring(bstring, encoding="UTF-8", delimiter="\n"):
    strings = get_strings_from_bstring(bstring,
                                       encoding=encoding,
                                       delimiter=delimiter)
    for string in strings:
        print(string)


def quadriflow_path_pref_is_set():
    """Determines if the quadriflow_path variable has been set in the
    Autoflow add-on's preferences.
    """
    quadriflow_path = get_quadriflow_path_from_addon_prefs()
    return quadriflow_path not in ["", None]


def remesh_with_quadriflow(input_path, output_path, min_cost_flow=False,
                           sharp_preserving=False, flip_removal=False,
                           resolution=1000, timeout=None):

    quadriflow_args = [get_quadriflow_path_from_addon_prefs(),
                       "-mcf" * min_cost_flow,
                       "-sharp" * sharp_preserving,
                       "-sat" * sat_flag_is_allowed() * flip_removal,
                       "-i", input_path,
                       "-o", output_path,
                       "-f", str(resolution)]
    return subprocess_popen(quadriflow_args, timeout=timeout)


def sat_flag_is_allowed():
    """Determines if the -sat flag can be used with the quadriflow
    command on this computer.
    """
    return (os_is_linux() or os_is_mac()) \
           and unix_executable_is_installed("minisat") \
           and unix_executable_is_installed("timeout")


def select_only_objects_in_view_layer(view_layer, *objects):
    set_selection_of_objects(False, *view_layer.objects)
    set_selection_of_objects(True, *objects)


def set_selection_of_objects(selection, *objects):
    for obj in objects:
        obj.select_set(state=selection)


def set_active_object_in_view_layer(view_layer, obj):
    view_layer.objects.active = obj


def subprocess_popen(command, timeout=30):
    process = subprocess.Popen(command,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE)
    try:
        output, errors = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        process.kill()
        output, errors = process.communicate()
    return output, errors


def unix_executable_is_installed(executable_command):
    """Determines if the executable command can be found using the
    which command.
    """
    subprocess_args = ["which", executable_command]
    output, errors = subprocess_popen(subprocess_args)
    return output != b''
