import bpy
from bpy.props import (BoolProperty,
                       IntProperty,
                       PointerProperty,
                       StringProperty)
from bpy.types import PropertyGroup


class AutoflowSettings(PropertyGroup):
    @classmethod
    def register(cls):
        bpy.types.Scene.autoflow = PointerProperty(
            name="Autoflow Settings",
            description="Autoflow settings",
            type=cls,
        )

        cls.flip_removal = BoolProperty(
            name="Flip Removal",
            description="Use SAT solver flag in QuadriFlow command",
            default=False,
        )

        cls.min_cost_flow = BoolProperty(
            name="Min-cost Flow",
            description="Use min-cost flow flag in QuadriFlow command",
            default=False,
        )

        cls.require_manifold = BoolProperty(
            name="Require Manifold Input",
            description="Require that input mesh is manifold",
            default=False,
        )

        cls.resolution = IntProperty(
            name="Resolution",
            description="Resolution parameter used in QuadriFlow command",
            min=1,
            default=1000,
        )

        cls.sharp_preserving = BoolProperty(
            name="Sharp Preserving",
            description="Use sharp preserving flag in QuadriFlow command",
            default=False,
        )

    @classmethod
    def unregister(cls):
        del bpy.types.Scene.autoflow
