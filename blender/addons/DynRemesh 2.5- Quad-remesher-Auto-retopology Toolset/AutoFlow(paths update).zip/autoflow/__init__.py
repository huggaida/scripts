# ##### BEGIN GPL LICENSE BLOCK #####
#
#  Autoflow: Automatically remesh objects in Blender using QuadriFlow.
#  Copyright (C) 2018 Dave C. (codingfreelance.dc@gmail.com)
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####


bl_info = {
    "name": "Autoflow",
    "description": "Automatically remesh objects using QuadriFlow.",
    "author": "Dave C. (codingfreelance.dc@gmail.com)",
    "version": (0, 2, 0),
    "blender": (2, 80, 0),
    "location": "View 3D > Sidebar > Autoflow",
    "warning": "",
    'wiki_url': "(To be added at a later date.)",
    "category": "Mesh"}


# Support reloading of add-on.
if "bpy" in locals():
    import importlib
    if "functions" in locals():
        importlib.reload(functions)
    if "operators" in locals():
        importlib.reload(operators)
    if "preferences" in locals():
        importlib.reload(preferences)
    if "properties" in locals():
        importlib.reload(properties)
    if "ui" in locals():
        importlib.reload(ui)
else:
    from . import (functions,
                   operators,
                   preferences,
                   properties,
                   ui)


import bpy
import sys
import os

classes = (operators.AUTOFLOW_OT_remesh,
           operators.AUTOFLOW_OT_remesh_dialog,
           preferences.AutoflowPreferences,
           properties.AutoflowSettings,
           ui.VIEW3D_PT_autoflow
           )


_addon_keymaps = []

def is_windows():
	
	from sys import platform as _platform

	if _platform == "win64":
		"..\\quadriflow.exe"
	
def _register_keymaps():
    key_configs = bpy.context.window_manager.keyconfigs
    keymap = key_configs.addon.keymaps.new(
        '3D View', space_type='VIEW_3D', region_type='WINDOW')
    keymap.keymap_items.new("autoflow.remesh_dialog", 'R', 'PRESS', ctrl=True)
    _addon_keymaps.append(keymap)


def _unregister_keymaps():
    key_configs = bpy.context.window_manager.keyconfigs
    for keymap in _addon_keymaps:
        for keymap_item in keymap.keymap_items:
            keymap.keymap_items.remove(keymap_item)
        key_configs.addon.keymaps.remove(keymap)
    _addon_keymaps.clear()


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    _register_keymaps()


def unregister():
    _unregister_keymaps()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
