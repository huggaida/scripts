from bpy.props import (StringProperty,
                       IntProperty)
from bpy.types import AddonPreferences
from sys import platform as _platform

class AutoflowPreferences(AddonPreferences):
    bl_idname = "autoflow"
	

	
    quadriflow_path: StringProperty(
        name="QuadriFlow Path",
        description="The path to the Quadriflow executable on this computer",
        subtype='FILE_PATH',
		
    )

    quadriflow_timeout: IntProperty(
        name="QuadriFlow Timeout (seconds)",
        description="Maximum time in seconds that Quadriflow is allowed to "
                    "remesh an object before a TimeoutExpired exception "
                    "is raised (set this value to zero to allow unlimited "
                    "time for remeshing)",
        min=0,
        default=300,
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "quadriflow_path")
        split = layout.split(factor=1/3)
        split.label(text="QuadriFlow Timeout (seconds):")
        split.prop(self, "quadriflow_timeout", text="")
