import bpy
import os
from bpy.types import Operator
from tempfile import TemporaryDirectory

from . import functions as funcs


class AutoflowOperator:
    bl_label = "Autoflow Remesh"
    bl_description = "Remesh the active object with QuadriFlow"
    bl_options = {'INTERNAL', 'UNDO'}

    @classmethod
    def poll(cls, context):
        active_obj = context.view_layer.objects.active
        return active_obj is not None and active_obj.mode == 'OBJECT'

    def execute(self, context):
        active_obj = context.view_layer.objects.active
        af = context.scene.autoflow
        view_layer = context.view_layer

        if af.require_manifold and not funcs.mesh_is_manifold(active_obj.data):
            self.report({'ERROR'},
                        "The \"Require Manifold Input\" option is set to "
                        "True, but the active object's mesh is not manifold, "
                        "so the object will not be remeshed.")
            return {'FINISHED'}

        initial_objects = funcs.get_objects_in_view_layer(view_layer)
        initial_selected_objects = \
            funcs.get_selected_objects_in_view_layer(view_layer)
        funcs.select_only_objects_in_view_layer(view_layer, active_obj)

        with TemporaryDirectory() as temp_directory:
            obj_path = os.path.join(temp_directory, active_obj.name + ".obj")

            print("Autoflow is exporting the active object for remeshing now.")
            bpy.ops.export_scene.obj(filepath=obj_path,
                                     use_selection=True,
                                     use_triangles=True)

            print("Autoflow is remeshing the active object now.  This may take "
                  "a while.")
            output_path = funcs.get_quadriflow_output_path(obj_path)
            timeout = funcs.get_quadriflow_timeout_from_addon_prefs()

            output, errors = funcs.remesh_with_quadriflow(obj_path,
                                                          output_path,
                                                          af.min_cost_flow,
                                                          af.sharp_preserving,
                                                          af.flip_removal,
                                                          af.resolution,
                                                          timeout)
            if not errors:
                print("Autoflow is importing the remeshed object now.")
                importing_path = funcs.get_quadriflow_output_path(obj_path)
                bpy.ops.import_scene.obj(filepath=importing_path)
            else:
                self.report({'ERROR'},
                            "There was an error during QuadriFlow processing.  "
                            "See the Blender system console for details.")
                print("\nOutput reported by QuadriFlow:")
                funcs.print_strings_from_bstring(output)
                print("\nError(s) reported by QuadriFlow:")
                funcs.print_strings_from_bstring(errors)

        new_objects = funcs.get_objects_in_view_layer(
            view_layer, objects_to_ignore=initial_objects)
        if new_objects:
            funcs.select_only_objects_in_view_layer(view_layer, *new_objects)
            funcs.set_active_object_in_view_layer(view_layer, new_objects[-1])
        else:
            funcs.select_only_objects_in_view_layer(view_layer,
                                                    *initial_selected_objects)

        print("Autoflow finished.")
        return {'FINISHED'}


class AUTOFLOW_OT_remesh(Operator, AutoflowOperator):
    bl_idname = "autoflow.remesh"


class AUTOFLOW_OT_remesh_dialog(Operator, AutoflowOperator):
    bl_idname = "autoflow.remesh_dialog"

    @staticmethod
    def pre_execution_error_message():
        if not funcs.quadriflow_path_pref_is_set():
            return "The QuadriFlow Path must be set in the Autoflow add-on " \
                   "preferences before Autoflow can be used."
        elif not os.path.exists(funcs.get_quadriflow_path_from_addon_prefs()):
            return "The QuadriFlow Path that is set in the Autoflow add-on " \
                   "preferences cannot be found on this computer.  Please " \
                   "change the QuadriFlow Path."
        elif not funcs.object_can_be_remeshed(
                bpy.context.view_layer.objects.active):
            return "A mesh must be selected in object mode to use Autoflow."
        elif not funcs.autoflow_is_compatible_with_os():
            return "Autoflow is not compatible with this operating system."
        else:
            return ""

    def draw(self, context):
        af = context.scene.autoflow

        layout = self.layout
        layout.prop(af, "min_cost_flow")
        layout.prop(af, "sharp_preserving")
        if funcs.sat_flag_is_allowed():
            layout.prop(af, "flip_removal")
        layout.prop(af, "require_manifold")
        layout.prop(af, "resolution")

    def invoke(self, context, event):
        error_message = self.pre_execution_error_message()
        if error_message:
            return self.report(('ERROR'), error_message)
        else:
            win_manager = context.window_manager
            return win_manager.invoke_props_dialog(self)
