import bpy, bmesh, mathutils, math
obj = bpy.context.object
bm = bmesh.from_edit_mesh(obj.data)
vrt = [vert.co for vert in bm.verts]

a = vrt[1].normalized()
b = vrt[3]
c = a 

#a.co.copy() = mathutils.Vector((1,1,1))
o = bm.verts.new((0.0, 0.0, 0.0))
#Cv = bm.verts.new(c) 
#bm.edges.new((Cv, o))



#mid_other
 
vec1 =  (vrt[2].copy() - vrt[1].copy() )
bm.edges.new((bm.verts.new(vec1), o))

vec2 =  (vrt[0].copy() - vrt[1].copy() )
bm.edges.new((bm.verts.new(vec2), o))

vc1 = vec1.copy()
vc2 = vec2.copy()

vc1.normalize()
vc2.normalize()

vec =  (vec1.copy() + vec2.copy() )
bm.edges.new((bm.verts.new(vec), o))

vc =  (vc1.copy() + vc2.copy() )
bm.edges.new((bm.verts.new(vc), o))

#new_pos
#ew_pos = 2 * (mid_other - vrt[2].copy()) + vrt[2].copy()
 
#bm.edges.new((bm.verts.new(new_pos), o))
#bm.edges.new((Cv, o))
#bm.edges.new((Cv, o))




bmesh.update_edit_mesh(obj.data)

#[vert.co for vert in bm.verts]
#bm.verts.ensure_lookup_table()
