# makepillow.py
Makes pillows in blender 2.8

Install via user preferences found in Edit > User Preferences > Addons

Install add-on from file. 

The addon should be available to enable in Add Mesh.
