bl_info = {
    "name": "F2 additions",
    "author": "Bart Crouch, Alexander Nedovizin, Paul Kotelevets "
              "(concept design)",
    "version": (1, 7, 2),
    "blender": (2, 70, 0),
    "location": "Editmode > F",
    "warning": "",
    "description": "Extends the 'Make Edge/Face' functionality",
    "wiki_url": "http://wiki.blender.org/index.php/Extensions:2.6/Py/"
                "Scripts/Modeling/F2",
    "category": "Mesh",
}

import bpy
from mesh_f2 import F2AddonPreferences, MeshF2

F2AddonPreferences.adjustuv = bpy.props.BoolProperty(
    name = "Adjust NEW UV",
    description =  "Automatically update UV unwrapping",
        default = True)

def register():
    for c in [MeshF2, F2AddonPreferences]:
        bpy.utils.unregister_class(c)
        bpy.utils.register_class(c)

def unregister():
    for c in  [ F2AddonPreferences, MeshF2]:
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
